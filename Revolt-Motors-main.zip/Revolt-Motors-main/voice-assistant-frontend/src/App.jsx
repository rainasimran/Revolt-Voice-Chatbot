
import { useEffect, useRef, useState } from "react";
import { io } from "socket.io-client";

// Connect to backend
const socket = io("http://localhost:5000"); // change URL if backend is elsewhere

export default function App() {
  const [messages, setMessages] = useState([]); // { from: 'me' | 'ai', text }
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef(null);

const [lang, setLang] = useState("en-US");

  // ---- Helpers ----
  const speak = (text) => {
    window.speechSynthesis.cancel(); // stop any ongoing TTS
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang;
    utterance.rate = 1;
    window.speechSynthesis.speak(utterance);
  };

  const addMessage = (from, text) =>
    setMessages((prev) => [...prev, { from, text }]);

  // ---- Socket events ----
  useEffect(() => {
    socket.on("connect", () => console.log("✅ Connected:", socket.id));

    socket.on("ai-reply", ({ text }) => {
      addMessage("ai", text);
      speak(text);
    });

    return () => {
      socket.off("connect");
      socket.off("ai-reply");
    };
  }, []);

  // ---- Speech Recognition setup ----
  const setupRecognition = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      alert("Your browser does not support Speech Recognition.");
      return null;
    }

    const rec = new SR();
    rec.lang = lang;
    rec.interimResults = true;
    rec.continuous = true;

    rec.onresult = (event) => {
      const last = event.results[event.results.length - 1];
      const transcript = last[0].transcript;
      if (last.isFinal) {
        addMessage("me", transcript);
        socket.emit("user-transcript", {
          text: transcript,
          lang: rec.lang, // comes from SpeechRecognition (like "en-US", "hi-IN")
        });
      }
    };

    rec.onerror = (e) => {
      console.error("STT error:", e);
      setListening(false);
    };

    rec.onend = () => setListening(false);

    return rec;
  };

  // Re-init recognition when language changes
  useEffect(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    recognitionRef.current = setupRecognition();
  // ✅ if user was already talking, auto-restart with new language
    if (listening) {
    recognitionRef.current.start();
  }
}, [lang]);

  const startListening = async () => {
    try {
      await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch {}
    if (!recognitionRef.current) {
      recognitionRef.current = setupRecognition();
      if (!recognitionRef.current) return;
    }
    window.speechSynthesis.cancel();
    recognitionRef.current.start();
    setListening(true);
  };

  const stopListening = () => {
    recognitionRef.current?.stop();
    setListening(false);
  };

  // ---- Render ----
  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#111",
        color: "#eee",
        padding: 32,
        fontFamily: "system-ui, sans-serif",
      }}
    >
      <h1 style={{ fontSize: 48, marginBottom: 24 }}>
        🎤 Revolt Motors Chatbot
      </h1>

      {/* ✅ Language selector dropdown */}
      <select
        value={lang}
        onChange={(e) => setLang(e.target.value)}
        style={{ marginBottom: 20, padding: 8, fontSize: 16 }}
      >
        <option value="en-US">English (US)</option>
        <option value="hi-IN">Hindi</option>
        <option value="es-ES">Spanish</option>
        <option value="fr-FR">French</option>
        <option value="de-DE">German</option>
      </select>

      <div style={{ display: "flex", gap: 12, marginBottom: 20 }}>
        {!listening ? (
          <button
            onClick={startListening}
            style={btnStyle("#6ee7b7", "#065f46")}
          >
            Start Talking
          </button>
        ) : (
          <button
            onClick={stopListening}
            style={btnStyle("#fca5a5", "#7f1d1d")}
          >
            Stop
          </button>
        )}
      </div>

      <div style={{ maxWidth: 720 }}>
        {messages.map((m, i) => (
          <p key={i} style={{ lineHeight: 1.6 }}>
            <strong>{m.from === "me" ? "You" : "AI"}:</strong> {m.text}
          </p>
        ))}
      </div>
    </div>
  );
}

// ---- Button style helper ----
function btnStyle(bg = "#fff", border = "#000") {
  return {
    background: bg,
    color: "#111",
    border: `2px solid ${border}`,
    padding: "12px 18px",
    fontSize: 18,
    borderRadius: 12,
    cursor: "pointer",
  };
}
